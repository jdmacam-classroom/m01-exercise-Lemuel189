package com.kalingapaws.lemsapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView TextUno;
    Button ButonSampol;
    String[] adobongSabaw = {
            "Honey never spoils, archaeologists found 3000-year-old edible honey.",
            "Octopuses have three hearts.",
            "A day on Venus is longer than a year on Venus.",
            "Bananas are berries, but strawberries aren't.",
            "Cowburps are a significant source of methane.",
            "The heart of a shrimp is located in its head.",
            "Sloths can hold their breath longer than dolphins.",
            "Wombat poop is cube-shaped.",
            "Nutmeg is a hallucinogen if eaten in large doses.",
            "A group of flamingos is called a 'flamboyance'."
    };
    int index=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        TextUno = findViewById(R.id.textView);
        ButonSampol = findViewById(R.id.button);
        ButonSampol.setOnClickListener(v -> {
            if (index < adobongSabaw.length) {
                TextUno.setText(adobongSabaw [index]);
                index++;}if (index >= adobongSabaw.length) {ButonSampol.setEnabled(false); ButonSampol.setText("Finished");}
        }); ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}